# Next Actions\n\n
## Immediate Next\n
1. 修复 OpenCLAW 真实对接
2. 修复历史记录持久化
\n## Verification Needed\n
- 真机测试眼镜首页显示
- 真机测试 R1 导航
