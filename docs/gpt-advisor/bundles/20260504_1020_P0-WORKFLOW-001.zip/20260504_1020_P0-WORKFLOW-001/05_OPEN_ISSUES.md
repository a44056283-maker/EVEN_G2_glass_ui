# Open Issues\n\n
## P0 Issues\n
- OpenCLAW 对接不完整
- 历史记录不保存
\n## P1 Issues\n
- 眼镜首页 4 菜单真机验证
- R1 导航功能真机验证
